import 'package:flutter/material.dart';
import 'package:http/http.dart'as http;
import 'dart:Converter';

void main() => runApp(MyApp(
  material(
    title: "Weather App",
    home: Home(),
  ),
));

class Home extends StatefulWidget{
  @override
  state<stateWidget> createSate(){
    return _Homestate();
  }
}
class _HomeState extends state<Home>{

   var temp;
   var description;
   var currently;
   var windspeed;
   var pressure;

   Feature getWeather () async {
     http.Response response = await http.get("http://api.openweathermap.org/data/2.5/weather?q=Nigeria&appid=e340cd96fad60816834f74c19e70a3ea");
     var results = jsonDecode(response.body);
     setSate((){
       this.temp=esults['main']['temp'];
       this.description=results['weather'][0]['desc;ription'];
       this.currently=results['weather'][0]['main'];
       this.windspeed=results['wind'][0]['speed'];
       this.pressure=results['main']['pressure'];
     });
   }

   @override
   void inistate(){
     super.inistate();
     this.getweather();
   }

   @overrride
   Widgetbuild(Buildcontext context){
     return Scaffold(
       body: Column(
               mainAxisAlignment: MainAxisAlignment.end,
               children: <Widget>[
                   Text("FlutLab is on your service!"),
                   Icon(Icons.mood),
               ],
             ),
         children: <Widget>[
           Container(
             height: MediaQuery(context).size.height/3,
             width: MediaQuery.of(context).size.width,
             color: Colors.green,
             child: Column(
               mainAxisAlignment: MainAxisAlignment.center,
               crossAxisAlignment: CrossAxisAlignment.center,
               children: <Widget>[
                 Padding(
                   padding: EdgeInsets.only(button: 12.0),
                   child: Text(
                     "Nigeria",
                     style: TextStyle(
                       color: Colors.white,
                       fontSize: 12.0,
                       fontWieght: FontWeight.W610
                     ),
                   ),
                 ),
                 Text(
                   temp != null? temp.toString() + "\u0B0" : "Loading",
                   style: TextStyle(
                     color: Colors.white,
                     fontSize: 440,
                     fontWeight: FontWeight.W610,
                   ),
                 ),
                 Padding(
                   padding: EdgeInsets.only(top: 10.0),
                   child: Text(
                     currently != null? currently.toString(): "Loading",
                     style: TextStyle(
                       color: Colors.white,
                       fontSize: 12.0,
                       fontWeight: fontWeight.w600
                     ),
                   ),
                 ),
               ],
             ),
           ),
           Expended(
             child: Padding(
               padding: EdgeInsets..all(20.0),
               child: ListView(
                 children: <widget>[
                   LisTile(
                     leading: Falcon(FontAwesomeIcons.thermometerHalf),
                     title: text("Temperature"),
                     trailing: Text(temp != null? temp.toString() + "\u00B0": "Loading"),
                   ),
                   LisTile(
                     leading: Falcon(FontAwesomeIcons.cloud),
                     title: Text("Weather"),
                     trailing: Text(description != null? description.toString(): "Loading"),
                   ),
                   LisTile(
                     leading: Falcon(FontAwesomeIcons.wind),
                     title: Text("WindSpeed"),
                     trailing: Text(windSpeed != null? windSpeed.toString(): "Loadng"),
                   ),
                   LisTile(
                     leading: Falcon(FontAwesomeIcons.pressure),
                     title: Text("Pressure"),
                     trialing: Text(pressure != null? pressure(): "Loading"),
                   ),
                 ],
               ),
             ),
           ),
         ],
        );
      );
    }  
  }
}
